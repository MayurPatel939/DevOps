from frappe import _

def get_data():
	return [
		{
			"module_name": "Erp Nb",
			"color": "grey",
			"icon": "octicon octicon-file-directory",
			"type": "module",
			"label": _("Erp Nb")
		}
	]
