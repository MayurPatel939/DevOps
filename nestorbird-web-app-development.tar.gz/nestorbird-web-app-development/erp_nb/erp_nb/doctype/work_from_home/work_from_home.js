// Copyright (c) 2022, Nestorbirdltd.com and contributors
// For license information, please see license.txt

frappe.ui.form.on('Work From home', {
	// refresh: function(frm) {

	// }
});


