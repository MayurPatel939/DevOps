# Copyright (c) 2022, Nestorbirdltd.com and contributors
# For license information, please see license.txt

import frappe
from datetime import datetime
from frappe.model.document import Document


class WorkFromhome(Document):
	def validate(self):
		self.validate_on_date()

	def validate_on_date(self):
		date = self.from_date
		employee = self.emloyee
		today = frappe.utils.nowdate()
		to_date = self.to_date
		dt = str(today)
		if dt>str(date):
			frappe.throw(
                "you can't apply work from home less then from date for {0}".format(employee))		
		if to_date<date:
			frappe.throw("from date is not less than to date")			

	def on_submit(self):
		self.add_att()

	def add_att(self):
		try:
			check_status = frappe.get_doc(
                "Work From home", {"docstatus":1})
			print("check_status")
			new_report = frappe.new_doc("Attendance")
			new_report.employee = check_status.emloyee
			new_report.attendance_date = check_status.from_date
			new_report.status = "Work From Home"
			new_report.docstatus =1
			new_report.save()
			print("fdxtdg")
		except:
			frappe.msgprint("None")


