// Copyright (c) 2022, Nestorbirdltd.com and contributors
// For license information, please see license.txt

frappe.ui.form.on('Sync With Hubspot', {
	sync_customer:function(){
		frappe.call({
			method:"erp_nb.api.doc_method.hubspot.customer"
			
		})
	},
	sync_sales_order:function(){
		frappe.call({
			method:"erp_nb.api.doc_method.hubspot.sales_order"
		})
	}
});
