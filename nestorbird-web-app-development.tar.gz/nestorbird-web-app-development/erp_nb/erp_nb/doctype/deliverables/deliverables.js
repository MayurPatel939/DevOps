// Copyright (c) 2021, Nestorbirdltd.com and contributors
// For license information, please see license.txt

frappe.ui.form.on('Deliverables', {
	// refresh: function(frm) {

	// }
});
