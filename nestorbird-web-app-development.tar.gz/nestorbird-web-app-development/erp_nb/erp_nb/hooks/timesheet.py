import frappe
from frappe import _
from frappe.model.document import Document
from frappe.utils import add_to_date, flt, get_datetime, getdate, time_diff_in_hours
from frappe.utils import cint, cstr, formatdate, get_datetime, getdate, nowdate
from datetime import datetime
from erpnext.projects.doctype.timesheet.timesheet import Timesheet


class CustomTimesheet(Document):
    def validate(self):
        self.validate_duplicate_record()

    def validate_duplicate_record(self):
        res = frappe.db.sql(
            """
			select name from `tabTimesheet`
			where employee=%s
			and activity_date=%s
			and name !=%s
			and docstatus != 2
			""",
            (self.employee, getdate(self.activity_date), self.name),
        )
        if res:
            frappe.throw(
				_("Timesheet for employee {0} is already Fill for the date {1}").format(
					frappe.bold(self.employee), frappe.bold(self.activity_date)
				)
			)
        
            

	 