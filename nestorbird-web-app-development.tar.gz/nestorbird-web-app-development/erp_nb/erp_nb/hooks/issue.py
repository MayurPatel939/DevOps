import frappe

from frappe.utils import (
	now_datetime
)


def validate_tasks(doc, method):
    status = frappe.db.get_value("Issue", doc.name, "status")
    if doc.status in ["Closed", "Resolved"] and status not in ["Resolved", "Closed"]:
        doc.resolution_date = frappe.flags.current_time or now_datetime()
        task = frappe.db.get_list('Task', filters={
            'issue': doc.name
        }, fields=['status'], as_list=True)
        if task:
            task1 = list(task)
            for ta in task1:
                ta2 = list(ta)
                if ta2[0] != 'Completed':
                    frappe.throw(("Some Tasks are not completed."))
                    # this is for testing

def create_issue(doc, method):
    try:
        issue = frappe.get_doc(
            {
            "doctype": "Issue",
            "subject": doc.subject,
            "description": doc.content,
            "raised_by": doc.sender
            }
        )
        issue.insert()
        frappe.db.commit()
        doc.reference_doctype = "Issue"
        doc.reference_name = issue.name
        doc.status = "Linked"
        # doc.save()
    except:
        frappe.log_error(frappe.get_traceback(),
                             frappe._("Error on creating lead from {} {}").format(doc.doctype, doc.name))
