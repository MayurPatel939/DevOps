import frappe

@frappe.whitelist()
def get_employees_test(date, department = None, branch = None, company = None):
    attendance_not_marked = []
    attendance_marked = []
    filters = {"status": "Active", "date_of_joining": ["<=", date]}

    for field, value in {'department': department,
		'branch': branch, 'company': company}.items():
	    if value:
		    filters[field] = value

    employee_list = frappe.get_list("Employee", fields=["employee", "employee_name","mark_attendance"], filters=filters, order_by="employee_name")
    marked_employee = {}
    for emp in frappe.get_list("Attendance", fields=["employee", "status"],
							   filters={"attendance_date": date}):
	    marked_employee[emp['employee']] = emp['status']

    for employee in employee_list:
	    employee['status==inactive'] = marked_employee.get(employee['employee'])
	    if employee['employee'] not in marked_employee:
             if employee["mark_attendance"]==1:
                  attendance_not_marked.append(employee)
	    else:
		    attendance_marked.append(employee)
    return {
		"marked": attendance_marked,
		"unmarked": attendance_not_marked   
    }
    