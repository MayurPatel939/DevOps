from . import __version__ as app_version

app_name = "erp_nb"
app_title = "Erp Nb"
app_publisher = "Nestorbirdltd.com"
app_description = "Nestorbird ERPNext Customization"
app_icon = "octicon octicon-file-directory"
app_color = "grey"
app_email = "info@nestorbird.com"
app_license = "MIT"

# Includes in <head>
# ------------------

# include js, css files in header of desk.html
# app_include_css = "/assets/erp_nb/css/erp_nb.css"
# app_include_js = "/assets/erp_nb/js/erp_nb.js"
app_include_js = "/assets/erp_nb/js/lms_button.js"

# include js, css files in header of web template
# web_include_css = "/assets/erp_nb/css/erp_nb.css"
# web_include_js = "/assets/erp_nb/js/erp_nb.js"

# include custom scss in every website theme (without file extension ".scss")
# website_theme_scss = "erp_nb/public/scss/website"

# include js, css files in header of web form
# webform_include_js = {"doctype": "public/js/doctype.js"}
# webform_include_css = {"doctype": "public/css/doctype.css"}
fixtures = ['Custom Field', 'Property Setter', "Report"]

# include js in page
# page_js = {"page" : "public/js/file.js"}

# include js in doctype views
doctype_js = {
    "Timesheet": "public/js/doctype_js/timesheet.js",
    "Attendance": "public/js/doctype_js/attendance.js",
    "Sales Order": "public/js/doctype_js/sales_order.js",
    "Issue": "public/js/doctype_js/issue.js",
    "Sales Order":"public/js/doctype_js/Sales_order_validate.js",
    "Sales Invoice":"public/js/fetch_timesheet.js"
}
# doctype_list_js = {"doctype" : "public/js/doctype_list.js"}
# doctype_tree_js = {"doctype" : "public/js/doctype_tree.js"}
# doctype_calendar_js = {"doctype" : "public/js/doctype_calendar.js"}

# Home Pages
# ----------

# application home page (will override Website Settings)
# home_page = "login"

# website user home page (by Role)
# role_home_page = {
#	"Role": "home_page"
# }

# Generators
# ----------

# automatically create page for each record of this doctype
# website_generators = ["Web Page"]

# Installation
# ------------

# before_install = "erp_nb.install.before_install"
# after_install = "erp_nb.install.after_install"

# Desk Notifications
# ------------------
# See frappe.core.notifications.get_notification_config

# notification_config = "erp_nb.notifications.get_notification_config"

# Permissions
# -----------
# Permissions evaluated in scripted ways

# permission_query_conditions = {
# 	"Event": "frappe.desk.doctype.event.event.get_permission_query_conditions",
# }
#
# has_permission = {
# 	"Event": "frappe.desk.doctype.event.event.has_permission",
# }

# DocType Class
# ---------------
# Override standard doctype classes

override_doctype_class = {
    # "ToDo": "custom_app.overrides.CustomToDo"
    "Timesheet": "erp_nb.erp_nb.hooks.timesheet.CustomTimesheet"


}

# Document Events
# ---------------
# Hook on document methods and events

doc_events = {
    # "*": {
    # 	"on_update": "method",
    # 	"on_cancel": "method",
    # 	"on_trash": "method"
    # }
    "Issue": {
        "validate": "erp_nb.erp_nb.hooks.issue.validate_tasks",

    },
    "Communication": {
        "on_update": "erp_nb.erp_nb.hooks.issue.create_issue"
    }
}
# doc_events = {
# 	"*": {
# 		"on_update": "method",
# 		"on_cancel": "method",
# 		"on_trash": "method"
# 	}
# }

# Scheduled Tasks
# ---------------
# edit by nisha and maneesh

scheduler_events = {
    "cron": {
        "0 10 * * *":[
	 		"erp_nb.api.doc_method.employee_resignation.validate"
	 	],
        "0 11 * * *": [
            "erp_nb.api.doc_method.attendance.attendance_reminder"
        ],
        "0 18 * * *": [
            "erp_nb.api.doc_method.attendance.attendance_reminder"
        ],
        "50 23 * * *": [
            "erp_nb.api.doc_method.attendance.attendance_check"
        ],
        "15 1 * * *":[
            "erp_nb.api.doc_method.hubspot.customer"
        ],
        "45 1 * * *":[
            "erp_nb.doc_method.hubspot.sales_order"
        ]
    },
    "all": [
     	"erp_nb.tasks.all"
     ],
     "daily": [
     	"erp_nb.tasks.daily"
    ],
     "hourly": [
     	"erp_nb.tasks.hourly"
     ],
    "weekly": [
     	"erp_nb.tasks.weekly"
    ],
     "monthly": [
     	"erp_nb.tasks.monthly"
    ]
}

# Testing
# -------

# before_tests = "erp_nb.install.before_tests"

# Overriding Methods
# ------------------------------
#
override_whitelisted_methods = {
    "erpnext.hr.doctype.employee_attendance_tool.employee_attendance_tool.get_employees": "erp_nb.erp_nb.employee_attendance_tool.get_employees_test",
    "erpnext.selling.doctype.sales_order.sales_order.make_sales_invoice":"erp_nb.erp_nb.hooks.payment_sales_invoice.make_sales_invoice",
    "erpnext.projects.doctype.timesheet.timesheet.get_projectwise_timesheet_data":"erp_nb.erp_nb.hooks.timesheet_data.get_projectwise_timesheet_data"
}


# each overriding function accepts a `data` argument;
# generated from the base implementation of the doctype dashboard,
# along with any modifications made in other Frappe apps
# override_doctype_dashboards = {
# 	"Task": "erp_nb.task.get_dashboard_data"
# }

# exempt linked doctypes from being automatically cancelled
#
# auto_cancel_exempted_doctypes = ["Auto Repeat"]


# User Data Protection
# --------------------

user_data_fields = [
    {
        "doctype": "{doctype_1}",
        "filter_by": "{filter_by}",
        "redact_fields": ["{field_1}", "{field_2}"],
        "partial": 1,
    },
    {
        "doctype": "{doctype_2}",
        "filter_by": "{filter_by}",
        "partial": 1,
    },
    {
        "doctype": "{doctype_3}",
        "strict": False,
    },
    {
        "doctype": "{doctype_4}"
    }
]

# Authentication and authorization
# --------------------------------

# auth_hooks = [
# 	"erp_nb.auth.validate"
# ]

fixtures = ["Report",'Workflow', 'Notification']


