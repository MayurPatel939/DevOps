frappe.ui.form.on('Attendance', {
  after_save: function(){
      if(cur_frm.doc.docstatus == 0){
          cur_frm.save('Submit');
      }  
  }
})