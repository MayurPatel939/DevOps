frappe.ui.form.on("Issue", {
   setup: function(frm){
       set_description(frm);
   }
});
function set_description(frm){
    frappe.call({
        method: 'frappe.client.get_value',
        args: {
            'doctype': 'Communication',
            'filters': {'reference_name': cur_frm.doc.name},
            'fieldname': [
                'text_content'
            ]
        },
        callback: function(r) {
         if(r.message.text_content){
            frm.set_value("description",r.message.text_content)
            }
        }
    });
}