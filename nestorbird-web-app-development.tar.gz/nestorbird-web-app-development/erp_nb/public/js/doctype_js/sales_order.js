frappe.ui.form.on('Sales Order', {
	commission_rate: function (frm) {
		var cm = frm.doc.commission_rate
		var tp = frm.doc.total_payment_amounts
		var commission_rate = parseFloat((cm * tp) / 100);
		frm.set_value("total_commision", commission_rate)
		refresh_field("total_commision")
		// console.log(commission_rate)
	}
})
