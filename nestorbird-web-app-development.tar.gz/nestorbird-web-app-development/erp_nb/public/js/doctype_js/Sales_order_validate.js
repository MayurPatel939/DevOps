frappe.ui.form.on("Sales Order", {
    before_save: function(frm) {

        console.log("hjgjjgjhjb")
        cur_frm.fields_dict.deliverables.grid.toggle_reqd
        ("milestone", frm.doc.sales_order_type=="Fixed")

        cur_frm.fields_dict.deliverables.grid.toggle_reqd
        ("task", frm.doc.sales_order_type=="Fixed")

        cur_frm.fields_dict.deliverables.grid.toggle_reqd
        ("duration", frm.doc.sales_order_type=="Fixed")
  
        cur_frm.fields_dict.payment_schedule.grid.toggle_reqd
        ("payment_term", frm.doc.sales_order_type=="Fixed")

        cur_frm.fields_dict.payment_schedule.grid.toggle_reqd
        ("due_date", frm.doc.sales_order_type=="Fixed")
      },
      refresh:function(frm){
        if(!frm.doc.deliverables|| frm.doc.deliverables.length<1){
        frm.add_child('deliverables',{})}
        if(!frm.doc.payment_schedule|| frm.doc.payment_schedule.length<1){
        frm.add_child('payment_schedule',{})
      }
    }
      
});
 
