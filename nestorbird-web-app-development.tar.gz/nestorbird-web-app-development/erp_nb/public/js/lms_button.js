$(document).ready(()=>{
          const params = window.location.origin
          this.lms_button = $(`<button type="button" id="devops" style="margin-left: 22px; border-color: #007bff" class="btn btn-primary btn-sm">Raise DevOps Ticket</button>`).insertAfter($('.navbar-collapse'))
           $('#devops').click(function() {
   window.open('https://support.nestorbird.com/support/tickets')
});
    })