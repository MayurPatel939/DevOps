
import frappe 
from frappe import _
from frappe.utils import getdate
from sre_parse import WHITESPACE


@frappe.whitelist()
def validate():
    emp_list = frappe.db.sql(
        """ select employee,workflow_state,modified from tabResignation  where modified <= now() - INTERVAL 60 day AND workflow_state="Approved by Department Head" """, as_dict=1)
    for i in range(len(emp_list)):
        print(emp_list[i]['employee'])
        doc=frappe.get_doc("Employee",emp_list[i]['employee'],)
        user_doc=frappe.get_doc("User",doc.user_id)
        user_doc.enabled=0
        user_doc.save()
        doc.status="Left"
        dt=frappe.utils.nowdate()
        doc.relieving_date=dt
        print(doc.status) 
        doc.save()
        frappe.db.commit()

    # emp_user = frappe.db.sql(
    #     """ select user_id from tabEmployee  where status="Left" """, as_dict=1)
    # for i in range(len(emp_user)):
    #     print(emp_user[i]['user_id'])
    #     doc=frappe.get_doc("User",emp_user[i]['user_id'])
    #     doc.enabled=0
    #     doc.save()
    #     frappe.db.commit()


    

