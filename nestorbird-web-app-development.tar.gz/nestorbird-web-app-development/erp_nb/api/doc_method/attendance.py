from __future__ import unicode_literals
from email.mime import image

import frappe
from frappe import _
from datetime import date
from frappe import utils
# *****Attendance Reminder


@frappe.whitelist()
def attendance_reminder():

    # holiday = frappe.db.sql(""" select h.holiday_date from `tabHoliday List` hl , `tabHoliday` h where hl.name = h.parent and hl.name in ("weekly holiday list 2","Holiday Calender") and h.holiday_date=curdate() group by h.holiday_date
	#   """)
    #query edit by nisha
    holiday = frappe.db.sql("""select holiday_date from `tabHoliday` where holiday_date=curdate()""")
    if holiday:
        pass
    else:
        unmark_attendance = frappe.db.sql(""" select e.name,e.employee_name from `tabEmployee` e where e.name not in (select a.employee from `tabAttendance` a where a.attendance_date=curdate()) and e.name not in (select la.employee from `tabLeave Application` la where curdate() between la.from_date and la.to_date) and e.status="Active" and e.receive_attendance_reminder=1

 """, as_dict=1)
        print(unmark_attendance)
        for user_obj in unmark_attendance:
            user = user_obj.name
            recipient = frappe.get_value("Employee", user, "prefered_email")

            frappe.sendmail(
                recipients=[recipient],
                subject="Attendance Reminder",
                message="Please Mark Your Today's Attendance",
                header=['Attendance Reminder', 'yellow'],
            )

# edit by nisha


def attendance_check(ignore_validate=False):
    holiday = frappe.db.sql("""select holiday_date from `tabHoliday` where holiday_date=curdate();
""")
    if holiday:
        pass
    else:
        blank = frappe.db.sql(""" select e.name,e.employee_name from `tabEmployee` e where e.name not in (select a.employee from `tabAttendance` a where a.attendance_date=curdate()) and e.name not in (select la.employee from `tabLeave Application` la where curdate() between la.from_date and la.to_date) and e.status="Active" and e.receive_attendance_reminder=1""", as_dict=1)
        print(blank)
        print("hello")
        for i in range(len(blank)):
            parent = frappe.new_doc('Attendance')
            # parent.employee = blank[i]["name"]
            parent.employee_name = blank[i]["employee_name"]
            print(parent.employee_name)
            parent.employee = blank[i]["name"]
            parent.attendance_date = date.today()
            parent.status = "Absent"
            parent.insert(ignore_permissions=True)
            parent.save()
            parent.submit()
            
            dates = frappe.utils.nowdate()
        #email sending for absent
            for e1 in blank:
                user = e1.name
                recipient = frappe.get_value("Employee", user, "prefered_email")

                frappe.sendmail(
                recipients=[recipient],
                subject="Absent Reminder",
                message="You have not marked the attendance, you are marked Absent for {0}".format(dates),
                header=['Absent Reminder', 'yellow'],
                )
    frappe.db.commit()


        # show = frappe.db.sql("""select employee_name,status from tabAttendance where attendance_date= CURDATE()""")
        # print(show)
    # parent.flags.ignore_validate = ignore_validate
    # parent.insert()
        # parent.submit()
    # return parent.name
# for user_obj in blank:
# 		user = user_obj.name
# 		if blank:
# 			user_obj.status = "Absent"
