import json
import requests
import  frappe
from datetime import date

@frappe.whitelist(allow_guest=True)
def sales_order():
    url = "https://api.hubapi.com/crm/v3/objects/deals/search"
    
    Api_key = frappe.db.get_single_value("Sync With Hubspot", "api_key")
    if Api_key:
      payload = json.dumps({
        "filters": [
          {
            "propertyName": "dealstage",
            "operator": "IN",
            "values": ["closedwon"]
          }

        ],
        "properties": [
          # "deal_service_category",
          "amount",
          "dealstage",
          "dealname",
          "closedate",
          # "lead_owner",
          "contact_email",
          "services"
          
        ],
        "limit":100,
      })

      headers = {
      # 'Authorization': 'Bearer pat-na1-e0b38319-9eb2-4067-99f2-977ce5baff61',
      'Authorization': 'Bearer '+ Api_key,
      'Content-Type': 'application/json' 
      }

      response = requests.request("POST", url, headers=headers, data=payload)

      deal_data = response.text

      deal_data2 = json.loads(deal_data)

      deal_data3 = deal_data2["results"]
      for i in deal_data3:
          data1=i['properties']['services']
          if data1 and not frappe.db.exists("Item", data1):
              new_item = frappe.new_doc("Item")
              new_item.item_code = data1
              new_item.standard_rate = i["properties"]["amount"]
              print(new_item.item_code)
              new_item.docstatus = 0
              new_item.flags.ignore_mandatory = True
              new_item.insert()  


      customer_email =  frappe.get_all("Customer",["customer_email","name"])
      print(customer_email)

      for i in deal_data3:
          emails = i["properties"]["contact_email"]
          for j in range(len(customer_email)):
              if emails == customer_email[j]['customer_email']:
                sales_order = frappe.db.get_values("Sales Order", {"hubspot_deal_id":i["properties"]["hs_object_id"]})
                if not sales_order:
                  new_sales_order = frappe.new_doc("Sales Order")
                  new_sales_order.customer=customer_email[j]['name']
                  new_sales_order.customer_email=customer_email[j]['customer_email']

                  new_sales_order.hubspot_deal_id = i["properties"]["hs_object_id"]

                  new_sales_order.dealstage = i["properties"]["dealstage"]
                  if i["properties"]["closedate"]:
                      new_sales_order.delivery_date = date.today()
                      
                  item =  i["properties"]["services"]

                  if item and not frappe.db.exists("Sales Order", item):
                    new_sales_order.append("items",{
                        "item_code":i["properties"]["services"],
                        "rate":i["properties"]["amount"],
                        "qty":1,
                    })

                  else:
                      new_sales_order.append("items",{
                        "item_code":"No service",
                        "rate":i["properties"]["amount"],
                        "qty":1,
                    }) 
                  
                  # deal_owner = i["properties"]["lead_owner"]
                  # if deal_owner and not frappe.db.exists("Sales Order", deal_owner):
                  #   new_sales_order.append("sales_team",{
                  #     "sales_person":i["properties"]["lead_owner"],
                  #     "allocated_percentage":100
                  #   })  
                  # else:
                  #   new_sales_order.append("sales_team",{
                  #     "sales_person":"Null",
                  #     "allocated_percentage":100
                  #   })
                  new_sales_order.flags.ignore_mandatory=True
                  new_sales_order.ignore_if_duplicate=True  
                  new_sales_order.insert() 
    else:
      frappe.throw("Please Enter The Api Key")




@frappe.whitelist(allow_guest=True)
def customer():
    url = "https://api.hubapi.com/crm/v3/objects/contacts?properties=email,phone,city,firstname,contact_email&limit=50"
    
    Api_key = frappe.db.get_single_value("Sync With Hubspot", "api_key")
    if Api_key:
      print("jkbjhhjhjbjubhu", url)
      headers = {
      # 'Authorization': 'Bearer pat-na1-e0b38319-9eb2-4067-99f2-977ce5baff61'
      'Authorization': 'Bearer '+ Api_key
      }

      payload = {}

      response = requests.request("GET", url, headers=headers, data=payload)
      data = response.text
      values = json.loads(data)
      
      contact_data2 = values["results"]


      for p in contact_data2:
          customer = frappe.db.get_value("Customer",{"deal_id":p["properties"]["hs_object_id"]})
          print(customer)
          if not customer:
            new_customer = frappe.new_doc("Customer")
            new_customer.customer_name = p["properties"]["firstname"]
            new_customer.deal_id = p["properties"]["hs_object_id"]
            new_customer.customer_email = p["properties"]["email"]
            new_customer.docstatus = 0
            new_customer.flags.ignore_mandatory=True
            new_customer.insert()
    else:
      frappe.throw("Please Enter The Api Key")         



