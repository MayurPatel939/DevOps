import frappe

def is_first_responsenb(issue):
	responses = frappe.get_all(
		"Communication", filters={"reference_name": issue.name, "sent_or_received": "Recieved"}
	)
	if len(responses) == 1:
		return True
	return False