import frappe


def custom_calculate_taxes_and_totals(self):
    from erpnext.controllers.taxes_and_totals import calculate_taxes_and_totals
    calculate_taxes_and_totals(self)

    if self.doctype in ["Quotation", "Sales Order", "Delivery Note", "Sales Invoice"]:
        self.calculate_commission()
        #self.calculate contribution ()


def custom_validate(self):
    self.validate_proj_cust()
    #self.validate_delivery_date()


def custom_before_update_after_submit(self):
    self.validate_po()
    self.validate_drop_ship()
    self.validate_supplier_after_submit()
    #self.validate delivery date()
