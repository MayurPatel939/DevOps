import frappe

def on_submit_timesheet(self):
    self.update_task_and_project()
    

def validate_timesheet(self):
	self.set_employee_name()
	self.set_status()
	self.validate_dates()
	self.validate_time_logs()
	self.update_cost()
	self.calculate_total_amounts()
	self.calculate_percentage_billed()
	self.set_dates()
