from __future__ import unicode_literals
from erpnext.projects.doctype.timesheet.timesheet import Timesheet
from erp_nb.api.doc_method.timesheet import on_submit_timesheet,validate_timesheet
from erpnext.hr.page.organizational_chart import organizational_chart
from erp_nb.api.doc_method.organizational_chart import custom_get_children
from erpnext.support.doctype.issue.issue import is_first_response
from erp_nb.api.doc_method.issue import  is_first_responsenb


__version__ = '0.0.1'

Timesheet.on_submit = on_submit_timesheet
Timesheet.validate = validate_timesheet
organizational_chart.get_children = custom_get_children
is_first_response = is_first_responsenb